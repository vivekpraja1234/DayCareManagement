---Indexes

---(Children table)Index on ParentID since you might frequently search for children based on their parent's ID:
CREATE INDEX idx_children_parentid ON Children (ParentID);

SELECT * FROM Children
WHERE ParentID = 1;


---(Enrollment table)Index on ChildID for faster retrieval of enrollments based on child ID:
CREATE INDEX idx_enrollment_childid ON Enrollment (ChildID);

---want to find the enrollment details along with age group descriptions for a specific child
SELECT e.EnrollmentID, e.StartDate, e.EndDate, ag.AgeGroupDescription
FROM Enrollment e
JOIN AgeGroups ag ON e.GroupID = ag.GroupID
WHERE e.ChildID = 5;


---(Attendance table)Index on ChildID for quicker access to attendance records by child ID:
CREATE INDEX idx_attendance_childid ON Attendance (ChildID);

---to retrieve the most recent attendance entry for a child with a specific ChildID:
SELECT 
    ChildID, 
    AttendanceDate, 
    ArrivalTime, 
    DepartureTime
FROM 
    Attendance
WHERE 
    ChildID = 4
ORDER BY 
    AttendanceDate DESC, DepartureTime DESC
FETCH FIRST 1 ROW ONLY;



---(Staff table)Index on StaffID for faster retrieval of staff schedules by staff ID:
CREATE INDEX idx_staffschedule_staffid ON StaffSchedule (StaffID);

SELECT * FROM StaffSchedule
WHERE StaffID =4
AND AssignedDate BETWEEN TO_DATE('2023-02-02', 'YYYY-MM-DD') AND TO_DATE('2023-06-02', 'YYYY-MM-DD');

    
---(Activities table)Index on ScheduledDate for quicker access to activities based on scheduled date:
CREATE INDEX idx_activities_scheduledate ON Activities (ScheduledDate);

---to find the activities scheduled on specific date
SELECT ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime
FROM Activities
WHERE ScheduledDate = TO_DATE('2023-03-04', 'YYYY-MM-DD');

---to find the activities scheduled between two specific date
SELECT ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime
FROM Activities
WHERE ScheduledDate BETWEEN TO_DATE('2023-03-01', 'YYYY-MM-DD') 
AND TO_DATE('2023-03-05', 'YYYY-MM-DD')
ORDER BY ScheduledDate ASC, StartTime ASC;
