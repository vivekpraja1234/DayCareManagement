
---Sequence for parents table(ParentID)
CREATE SEQUENCE parents_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

---Sequence for Children table(ChildID)
CREATE SEQUENCE children_seq START WITH 1 INCREMENT BY 1;

--Sequence for Attendence(AttendenceID)
CREATE SEQUENCE attendance_seq
START WITH 1
INCREMENT BY 1
NOMAXVALUE;

-- Sequence for Staff table (StaffID)
CREATE SEQUENCE staff_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for AgeGroups table (GroupID)
CREATE SEQUENCE agegroups_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for Enrollment table (EnrollmentID)
CREATE SEQUENCE enrollment_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for GroupTimings table (TimingID)
CREATE SEQUENCE grouptimings_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for Fees table (FeeID)
CREATE SEQUENCE fees_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for StaffSchedule table (ScheduleID)
CREATE SEQUENCE staffschedule_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;

-- Sequence for Activities table (ActivityID)
CREATE SEQUENCE activities_seq
START WITH 1
INCREMENT BY 1
NOCACHE
NOCYCLE;