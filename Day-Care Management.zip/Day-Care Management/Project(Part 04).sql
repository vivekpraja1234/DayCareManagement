---Triggers
drop trigger calculate_fees_on_enrollment;
drop trigger pre_del_act_enroll;
drop trigger prevent_column_update;


---To calculate fees on enrollment
ALTER TABLE Enrollment
ADD TotalFee DECIMAL(10, 2);


CREATE OR REPLACE TRIGGER calculate_fees_on_enrollment
BEFORE INSERT ON Enrollment
FOR EACH ROW
DECLARE
    v_weekday_rate DECIMAL(10, 2);
    v_weekend_rate DECIMAL(10, 2);
BEGIN
    SELECT WeekdayRate, WeekendRate
    INTO v_weekday_rate, v_weekend_rate
    FROM Fees
    WHERE GroupID = :NEW.GroupID
    AND EffectiveDate <= :NEW.StartDate
    ORDER BY EffectiveDate DESC
    FETCH FIRST 1 ROW ONLY;

    :NEW.TotalFee := 
          (v_weekday_rate * (NEXT_DAY(:NEW.StartDate, 'SATURDAY') - GREATEST(:NEW.StartDate, TRUNC(:NEW.StartDate)))) + 
          (v_weekend_rate * (LEAST(NEXT_DAY(:NEW.EndDate, 'SUNDAY'), :NEW.EndDate) - NEXT_DAY(:NEW.StartDate, 'SATURDAY')));
END;
/


--- Insert test data into the Enrollment table
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate)
VALUES (enrollment_seq.NEXTVAL, 2, 1, DATE '2024-04-01', DATE '2024-04-15');

INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate)
VALUES (enrollment_seq.NEXTVAL, 4, 3, DATE '2024-04-11', DATE '2024-04-15');

select * from enrollment;



---Trigger to Prevent Deletion of Active Enrollment Records:
CREATE OR REPLACE TRIGGER pre_del_act_enroll
BEFORE DELETE ON Enrollment
FOR EACH ROW
BEGIN
    IF :OLD.EndDate IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Cannot delete active enrollment records.');
    END IF;
END;
/

select * from enrollment;

-- Attempt to delete an active enrollment record
DELETE FROM Enrollment
WHERE EnrollmentID = 7; 

UPDATE Enrollment
SET EndDate = NULL
WHERE EndDate = TO_DATE('2023-08-01', 'YYYY-MM-DD');


----trigger that prevents updates on a specific column

CREATE OR REPLACE TRIGGER prevent_column_update
BEFORE UPDATE ON agegroups
FOR EACH ROW
BEGIN
    IF UPDATING ('AgeGroupDescription') THEN
        RAISE_APPLICATION_ERROR(-20001, 'Updates to AgeGroupDescription are not allowed.');
    END IF;
END;
/

-- Attempt to update the RestrictedColumn
UPDATE agegroups
SET AgeGroupDescription = 'Play'
WHERE AgeGroupDescription = 'Toddler'; 




 


