--A package named ChildCareManagement that includes:
--A procedure to enroll a child into a group.
--A function to calculate the total fees for a given enrollment, taking into account both weekday and weekend rates.
--A procedure to update attendance records.
--Exception handling for common scenarios, such as attempting to enroll a child in a full group or a group not suitable for their age.

---Package Structure

drop package ChildCareManagement;
CREATE OR REPLACE PACKAGE ChildCareManagement IS

    -- Exceptions
    e_group_full EXCEPTION;
    e_inappropriate_age_group EXCEPTION;
    e_enrollment_not_found EXCEPTION;

    -- Procedure to enroll a child in a group
    PROCEDURE EnrollChild(
        p_ChildID IN INT,
        p_GroupID IN INT,
        p_StartDate IN DATE,
        p_EndDate IN DATE);

    -- Function to calculate total fees for an enrollment
    FUNCTION CalculateTotalFees(
        p_EnrollmentID IN INT) RETURN DECIMAL;

    -- Procedure to update attendance
    PROCEDURE UpdateAttendance(
        p_AttendanceID IN INT,
        p_ArrivalTime IN TIMESTAMP,
        p_DepartureTime IN TIMESTAMP);

END ChildCareManagement;
/

---Package Body
CREATE OR REPLACE PACKAGE BODY ChildCareManagement IS

    PROCEDURE EnrollChild(
        p_ChildID IN INT,
        p_GroupID IN INT,
        p_StartDate IN DATE,
        p_EndDate IN DATE) IS
        v_group_capacity INT;
        v_current_enrollment INT;
    BEGIN
        -- Check group capacity and current enrollment
        SELECT MaxAge INTO v_group_capacity FROM AgeGroups WHERE GroupID = p_GroupID;
        SELECT COUNT(*) INTO v_current_enrollment FROM Enrollment WHERE GroupID = p_GroupID;

        IF v_current_enrollment >= v_group_capacity THEN
            RAISE e_group_full;
        END IF;

        INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate)
        VALUES (enrollment_seq.NEXTVAL, p_ChildID, p_GroupID, p_StartDate, p_EndDate);
    END EnrollChild;

    FUNCTION CalculateTotalFees(
        p_EnrollmentID IN INT) RETURN DECIMAL IS
        v_weekday_rate DECIMAL(10,2);
        v_weekend_rate DECIMAL(10,2);
        v_total_fees DECIMAL(10,2) := 0;
    BEGIN
        -- to calculate fees based on the group and days
        SELECT WeekdayRate, WeekendRate INTO v_weekday_rate, v_weekend_rate
        FROM Fees JOIN Enrollment ON Fees.GroupID = Enrollment.GroupID
        WHERE Enrollment.EnrollmentID = p_EnrollmentID;

        -- Calculate total fees 
        v_total_fees := v_weekday_rate + v_weekend_rate; 
        RETURN v_total_fees;
    END CalculateTotalFees;

    PROCEDURE UpdateAttendance(
        p_AttendanceID IN INT,
        p_ArrivalTime IN TIMESTAMP,
        p_DepartureTime IN TIMESTAMP) IS
    BEGIN
        -- Update Attendance record
        UPDATE Attendance SET
        ArrivalTime = p_ArrivalTime,
        DepartureTime = p_DepartureTime
        WHERE AttendanceID = p_AttendanceID;
    END UpdateAttendance;

END ChildCareManagement;
/

---Check Procedure
BEGIN
  ChildCareManagement.EnrollChild(
    p_ChildID    => 1,
    p_GroupID    => 2,
    p_StartDate  => TO_DATE('2024-01-01', 'YYYY-MM-DD'),
    p_EndDate    => TO_DATE('2024-12-31', 'YYYY-MM-DD')
  );
END;
/
DECLARE
  v_fees DECIMAL;
BEGIN
  v_fees := ChildCareManagement.CalculateTotalFees(p_EnrollmentID => 1);
  DBMS_OUTPUT.PUT_LINE('Total Fees: ' || TO_CHAR(v_fees));
END;
/

---Check Function
BEGIN
  ChildCareManagement.UpdateAttendance(
    p_AttendanceID  => 1,
    p_ArrivalTime   => TO_TIMESTAMP('2024-01-01 08:00:00', 'YYYY-MM-DD HH24:MI:SS'),
    p_DepartureTime => TO_TIMESTAMP('2024-01-01 14:00:00', 'YYYY-MM-DD HH24:MI:SS')
  );
END;
/

---Check Exceptional Handling
DECLARE
  v_child_id INT := 1; -- Example child ID
  v_group_id INT := 2; -- Example group ID
  v_start_date DATE := TO_DATE('2024-01-01', 'YYYY-MM-DD');
  v_end_date DATE := TO_DATE('2024-12-31', 'YYYY-MM-DD');
BEGIN
  -- Attempt to enroll a child in a group
  ChildCareManagement.EnrollChild(
    p_ChildID   => v_child_id,
    p_GroupID   => v_group_id,
    p_StartDate => v_start_date,
    p_EndDate   => v_end_date
  );

  DBMS_OUTPUT.PUT_LINE('Child enrolled successfully.');

EXCEPTION
  WHEN ChildCareManagement.e_group_full THEN
    DBMS_OUTPUT.PUT_LINE('Cannot enroll child. The group is full.');
    
  WHEN ChildCareManagement.e_inappropriate_age_group THEN
    DBMS_OUTPUT.PUT_LINE('Cannot enroll child. Inappropriate age group.');

  WHEN OTHERS THEN
    -- Handles any other unexpected errors
    DBMS_OUTPUT.PUT_LINE('An unexpected error occurred: ' || SQLERRM);
END;
/





---Package Structure
drop package ActivitiesCommunication;
CREATE OR REPLACE PACKAGE ActivitiesCommunication IS

  -- Exception for when an activity is not found
  e_activity_not_found EXCEPTION;

  -- Exception for when sending a notification fails
  e_notification_failure EXCEPTION;

  -- Procedure to add a new activity
  PROCEDURE AddActivity(p_group_id IN INT, p_description IN VARCHAR2, p_scheduled_date IN DATE, p_start_time IN TIMESTAMP, p_end_time IN TIMESTAMP);

  -- Procedure to notify parents about an upcoming activity
  PROCEDURE NotifyParents(p_activity_id IN INT);

  -- Function to collect feedback for an activity
  FUNCTION CollectFeedback(p_activity_id IN INT) RETURN VARCHAR2;

END ActivitiesCommunication;
/

---Package  Body
CREATE OR REPLACE PACKAGE BODY ActivitiesCommunication IS

  PROCEDURE AddActivity(p_group_id IN INT, p_description IN VARCHAR2, p_scheduled_date IN DATE, p_start_time IN TIMESTAMP, p_end_time IN TIMESTAMP) IS
  BEGIN
    INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime)
    VALUES (activities_seq.NEXTVAL, p_group_id, p_description, p_scheduled_date, p_start_time, p_end_time);
  END AddActivity;

  PROCEDURE NotifyParents(p_activity_id IN INT) IS
    v_group_id INT;
    v_description VARCHAR2(255);
    v_scheduled_date DATE;
  BEGIN
    SELECT GroupID, ActivityDescription, ScheduledDate INTO v_group_id, v_description, v_scheduled_date FROM Activities WHERE ActivityID = p_activity_id;
    
    -- Example of sending a notification, simplified for illustration
    DBMS_OUTPUT.PUT_LINE('Notifying parents about activity: ' || v_description || ' on ' || TO_CHAR(v_scheduled_date, 'DD-MON-YYYY'));
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      RAISE e_activity_not_found;
  END NotifyParents;

  FUNCTION CollectFeedback(p_activity_id IN INT) RETURN VARCHAR2 IS
    v_feedback VARCHAR2(4000);
  BEGIN
    -- Placeholder for feedback collection logic
    v_feedback := 'Feedback collected for activity ID ' || p_activity_id;
    RETURN v_feedback;
  END CollectFeedback;

END ActivitiesCommunication;
/

EXEC ActivitiesCommunication.AddActivity(1, 'Outdoor Playtime', SYSDATE, TIMESTAMP '2024-04-01 09:00:00', TIMESTAMP '2024-04-01 11:00:00');

EXEC ActivitiesCommunication.NotifyParents(1);

DECLARE
  feedback_text VARCHAR2(4000);
BEGIN
  feedback_text := ActivitiesCommunication.CollectFeedback(1);
  DBMS_OUTPUT.PUT_LINE(feedback_text);
END;
/

