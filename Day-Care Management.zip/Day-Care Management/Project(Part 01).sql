DROP TABLE PARENTS CASCADE CONSTRAINTS;
DROP TABLE CHILDREN CASCADE CONSTRAINTS;
DROP TABLE ATTENDANCE CASCADE CONSTRAINTS;
DROP TABLE FEES CASCADE CONSTRAINTS;
DROP TABLE ENROLLMENT CASCADE CONSTRAINTS;
DROP TABLE STAFFSCHEDULE CASCADE CONSTRAINTS;
DROP TABLE AGEGROUPS CASCADE CONSTRAINTS;
DROP TABLE GROUPTIMINGS CASCADE CONSTRAINTS;
DROP TABLE ACTIVITIES CASCADE CONSTRAINTS;
DROP TABLE STAFF CASCADE CONSTRAINTS;

DROP SEQUENCE PARENTS_SEQ;
DROP SEQUENCE CHILDREN_SEQ;
DROP SEQUENCE ATTENDANCE_SEQ;
DROP SEQUENCE FEES_SEQ;
DROP SEQUENCE ENROLLMENT_SEQ;
DROP SEQUENCE STAFFSCHEDULE_SEQ;
DROP SEQUENCE AGEGROUPS_SEQ;
DROP SEQUENCE GROUPTIMINGS_SEQ;
DROP SEQUENCE ACTIVITIES_SEQ;
DROP SEQUENCE STAFF_SEQ;

---Parents Table
CREATE TABLE Parents(
    ParentID INT NOT NULL PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Email VARCHAR(100),
    Phone VARCHAR(20)
);

---Children Table
CREATE TABLE Children (
    ChildID INT NOT NULL PRIMARY KEY,
    FirstName VARCHAR2(50),
    LastName VARCHAR2(50),
    BirthDate DATE,
    ParentID INT,
    EnrollmentDate DATE,
    CONSTRAINT fk_parentID FOREIGN KEY (ParentID) REFERENCES Parents(ParentID)
);


---Staff Table
CREATE TABLE Staff (
    StaffID INT NOT NULL PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    Role VARCHAR(50),
    HireDate DATE
);

---AgeGroups Table
CREATE TABLE AgeGroups (
    GroupID INT Not Null PRIMARY KEY,
    AgeGroupDescription VARCHAR(100),
    MinAge INT,
    MaxAge INT
);

---Enrollment Table
CREATE TABLE Enrollment (
    EnrollmentID INT NOT NULL PRIMARY KEY,
    ChildID INT,
    GroupID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (ChildID) REFERENCES Children(ChildID),
    FOREIGN KEY (GroupID) REFERENCES AgeGroups(GroupID)
);

---Group Timings
CREATE TABLE GroupTimings (
    TimingID INT NOT NULL PRIMARY KEY,
    GroupID INT,
    WeekdayStartTime DATE,
    WeekdayEndTime DATE,
    WeekendStartTime TIMESTAMP,
    WeekendEndTime TIMESTAMP,
    FOREIGN KEY (GroupID) REFERENCES AgeGroups(GroupID)
);

---Fees Table
CREATE TABLE Fees (
    FeeID INT NOT NULL PRIMARY KEY,
    GroupID INT,
    WeekdayRate DECIMAL(10,2),
    WeekendRate DECIMAL(10,2),
    EffectiveDate DATE,
    FOREIGN KEY (GroupID) REFERENCES AgeGroups(GroupID)
);

---Staff Schedule Table
CREATE TABLE StaffSchedule (
    ScheduleID INT NOT NULL PRIMARY KEY,
    StaffID INT,
    GroupID INT,
    AssignedDate DATE,
    StartTime TIMESTAMP,
    EndTime TIMESTAMP,
    FOREIGN KEY (StaffID) REFERENCES Staff(StaffID),
    FOREIGN KEY (GroupID) REFERENCES AgeGroups(GroupID)
);

---Activities Table
CREATE TABLE Activities (
    ActivityID INT NOT NULL PRIMARY KEY,
    GroupID INT,
    ActivityDescription VARCHAR(255),
    ScheduledDate DATE,
    StartTime TIMESTAMP,
    EndTime TIMESTAMP,
    FOREIGN KEY (GroupID) REFERENCES AgeGroups(GroupID)
);

---Attendence Table
CREATE TABLE Attendance (
    AttendanceID INT NOT NULL,
    ChildID INT,
    AttendanceDate DATE,
    ArrivalTime TIMESTAMP,
    DepartureTime TIMESTAMP,
    PRIMARY KEY (AttendanceID),
    FOREIGN KEY (ChildID) REFERENCES Children(ChildID)
);



ALTER SESSION SET NLS_DATE_FORMAT='YYYY-MM-DD';


---Records for Parents table
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'John', 'Doe', 'john.doe@email.com', '555-0100');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Jane', 'Smith', 'jane.smith@email.com', '555-0101');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Michael', 'Johnson', 'michael.johnson@email.com', '555-0102');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Emily', 'Williams', 'emily.williams@email.com', '555-0103');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'David', 'Brown', 'david.brown@email.com', '555-0104');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Jessica', 'Davis', 'jessica.davis@email.com', '555-0105');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Charles', 'Miller', 'charles.miller@email.com', '555-0106');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Sarah', 'Wilson', 'sarah.wilson@email.com', '555-0107');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Thomas', 'Moore', 'thomas.moore@email.com', '555-0108');
INSERT INTO Parents (ParentID, FirstName, LastName, Email, Phone) VALUES (parents_seq.NEXTVAL, 'Patricia', 'Taylor', 'patricia.taylor@email.com', '555-0109');

---Records for Children table
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Alice', 'Doe', DATE '2015-01-01', 1, DATE '2022-02-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Bob', 'Doe', DATE '2016-03-01', 2, DATE '2022-03-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Charlie', 'Smith', DATE '2014-05-01', 3, DATE '2022-04-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Daisy', 'Johnson', DATE '2017-07-01', 4, DATE '2022-05-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Ethan', 'Williams', DATE '2013-09-01', 5, DATE '2022-06-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Fiona', 'Brown', DATE '2012-11-01', 6, DATE '2022-07-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'George', 'Davis', DATE '2015-02-01', 7, DATE '2022-08-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Hannah', 'Miller', DATE '2016-04-01', 8, DATE '2022-09-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Ian', 'Wilson', DATE '2014-06-01', 9, DATE '2022-10-01');
INSERT INTO Children (ChildID, FirstName, LastName, BirthDate, ParentID, EnrollmentDate) VALUES (children_seq.NEXTVAL, 'Julia', 'Moore', DATE '2017-08-01', 10, DATE '2022-11-01');

---Records for Staff table
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Sarah', 'Green', 'Teacher', DATE '2020-01-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'James', 'Hall', 'Assistant', DATE '2020-02-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Linda', 'Brown', 'Coordinator', DATE '2020-03-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Brian', 'Clark', 'Teacher', DATE '2020-04-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Nancy', 'Allen', 'Teacher', DATE '2020-05-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Gary', 'Young', 'Administrator', DATE '2020-06-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Diane', 'Harris', 'Teacher', DATE '2020-07-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Edward', 'Lewis', 'Assistant', DATE '2020-08-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Rebecca', 'Walker', 'Teacher', DATE '2020-09-01');
INSERT INTO Staff (StaffID, FirstName, LastName, Role, HireDate) VALUES (staff_seq.NEXTVAL, 'Charles', 'Robinson', 'Principal', DATE '2020-10-01');

---Records for AgeGroups Table
INSERT INTO AgeGroups (GroupID, AgeGroupDescription, MinAge, MaxAge) VALUES (agegroups_seq.NEXTVAL, 'Pre-Kindergarten', 4, 5);
INSERT INTO AgeGroups (GroupID, AgeGroupDescription, MinAge, MaxAge) VALUES (agegroups_seq.NEXTVAL, 'Preschool', 3, 4);
INSERT INTO AgeGroups (GroupID, AgeGroupDescription, MinAge, MaxAge) VALUES (agegroups_seq.NEXTVAL, 'Kindergarten', 5, 6);
INSERT INTO AgeGroups (GroupID, AgeGroupDescription, MinAge, MaxAge) VALUES (agegroups_seq.NEXTVAL, 'Toddler', 1, 3);

---Records for Enrollment table
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 1, 4, DATE '2022-02-01', DATE '2023-02-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 2, 3, DATE '2022-03-01', DATE '2023-03-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 3, 3, DATE '2022-04-01', DATE '2023-04-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 4, 2, DATE '2022-05-01', DATE '2023-05-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 5, 2, DATE '2022-06-01', DATE '2023-06-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 6, 1, DATE '2022-07-01', DATE '2023-07-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 7, 1, DATE '2022-08-01', DATE '2023-08-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 8, 4, DATE '2022-09-01', DATE '2023-09-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 9, 3, DATE '2022-10-01', DATE '2023-10-01');
INSERT INTO Enrollment (EnrollmentID, ChildID, GroupID, StartDate, EndDate) VALUES (enrollment_seq.NEXTVAL, 10, 2, DATE '2022-11-01', DATE '2023-11-01');


---Records for Fees table
INSERT INTO Fees (FeeID, GroupID, WeekdayRate, WeekendRate, EffectiveDate) VALUES (fees_seq.NEXTVAL, 1, 100.00, 150.00, DATE '2022-01-01');
INSERT INTO Fees (FeeID, GroupID, WeekdayRate, WeekendRate, EffectiveDate) VALUES (fees_seq.NEXTVAL, 2, 110.00, 160.00, DATE '2022-01-01');
INSERT INTO Fees (FeeID, GroupID, WeekdayRate, WeekendRate, EffectiveDate) VALUES (fees_seq.NEXTVAL, 3, 120.00, 170.00, DATE '2022-01-01');
INSERT INTO Fees (FeeID, GroupID, WeekdayRate, WeekendRate, EffectiveDate) VALUES (fees_seq.NEXTVAL, 4, 130.00, 180.00, DATE '2022-01-01');


---Records for Attendance table
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 1, DATE '2022-02-02', TO_TIMESTAMP('08:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:00:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 2, DATE '2022-03-02', TO_TIMESTAMP('08:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:30:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 3, DATE '2022-04-02', TO_TIMESTAMP('09:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('16:00:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 4, DATE '2022-05-02', TO_TIMESTAMP('07:45:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:45:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 5, DATE '2022-06-02', TO_TIMESTAMP('08:15:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:15:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 6, DATE '2022-07-02', TO_TIMESTAMP('09:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('16:30:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 7, DATE '2022-08-02', TO_TIMESTAMP('08:45:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:45:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 8, DATE '2022-09-02', TO_TIMESTAMP('07:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('13:30:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 9, DATE '2022-10-02', TO_TIMESTAMP('08:20:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:20:00', 'HH24:MI:SS'));
INSERT INTO Attendance (AttendanceID, ChildID, AttendanceDate, ArrivalTime, DepartureTime) VALUES (attendance_seq.NEXTVAL, 10, DATE '2022-11-02', TO_TIMESTAMP('09:15:00', 'HH24:MI:SS'), TO_TIMESTAMP('16:15:00', 'HH24:MI:SS'));


---Records for StaffSchedule table
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 1, 1, DATE '2023-03-01', TO_TIMESTAMP('08:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('12:00:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 2, 2, DATE '2023-03-02', TO_TIMESTAMP('12:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('16:00:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 3, 3, DATE '2023-03-03', TO_TIMESTAMP('09:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('13:00:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 4, 4, DATE '2023-03-04', TO_TIMESTAMP('10:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:00:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 5, 1, DATE '2023-03-05', TO_TIMESTAMP('11:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:00:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 6, 2, DATE '2023-03-06', TO_TIMESTAMP('08:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('12:30:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 7, 3, DATE '2023-03-07', TO_TIMESTAMP('12:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('16:30:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 8, 4, DATE '2023-03-08', TO_TIMESTAMP('09:15:00', 'HH24:MI:SS'), TO_TIMESTAMP('13:15:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 9, 1, DATE '2023-03-09', TO_TIMESTAMP('10:15:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:15:00', 'HH24:MI:SS'));
INSERT INTO StaffSchedule (ScheduleID, StaffID, GroupID, AssignedDate, StartTime, EndTime) VALUES (staffschedule_seq.NEXTVAL, 10, 2, DATE '2023-03-10', TO_TIMESTAMP('11:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('15:00:00', 'HH24:MI:SS'));

---Records for Activities table
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 4, 'Sensory Play', DATE '2023-03-01', TO_TIMESTAMP('09:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('10:00:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 2, 'Story Time', DATE '2023-03-02', TO_TIMESTAMP('10:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('11:00:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 1, 'Basic Math Games', DATE '2023-03-03', TO_TIMESTAMP('11:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('12:00:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 3, 'Science Experiment', DATE '2023-03-04', TO_TIMESTAMP('13:00:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:00:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 4, 'Music and Movement', DATE '2023-03-05', TO_TIMESTAMP('09:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('10:30:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 2, 'Art and Craft', DATE '2023-03-06', TO_TIMESTAMP('10:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('11:30:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 1, 'Letter Recognition', DATE '2023-03-07', TO_TIMESTAMP('11:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('12:30:00', 'HH24:MI:SS'));
INSERT INTO Activities (ActivityID, GroupID, ActivityDescription, ScheduledDate, StartTime, EndTime) VALUES (activities_seq.NEXTVAL, 3, 'Outdoor Exploration', DATE '2023-03-08', TO_TIMESTAMP('13:30:00', 'HH24:MI:SS'), TO_TIMESTAMP('14:30:00', 'HH24:MI:SS'));

---Records for GroupTimings table
INSERT INTO GroupTimings (TimingID, GroupID, WeekdayStartTime, WeekdayEndTime, WeekendStartTime, WeekendEndTime) VALUES (grouptimings_seq.NEXTVAL, 4, TO_TIMESTAMP('2023-01-01 07:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-01 12:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-07 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-07 11:00:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO GroupTimings (TimingID, GroupID, WeekdayStartTime, WeekdayEndTime, WeekendStartTime, WeekendEndTime) VALUES (grouptimings_seq.NEXTVAL, 2, TO_TIMESTAMP('2023-01-02 08:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-02 13:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-08 09:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-08 11:30:00', 'YYYY-MM-DD HH24:MI:SS'));
INSERT INTO GroupTimings (TimingID, GroupID, WeekdayStartTime, WeekdayEndTime, WeekendStartTime, WeekendEndTime) VALUES (grouptimings_seq.NEXTVAL, 1, TO_TIMESTAMP('2023-01-03 08:30:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-03 13:30:00', 'YYYY-MM-DD HH24:MI:SS'), NULL, NULL);
INSERT INTO GroupTimings (TimingID, GroupID, WeekdayStartTime, WeekdayEndTime, WeekendStartTime, WeekendEndTime) VALUES (grouptimings_seq.NEXTVAL, 3, TO_TIMESTAMP('2023-01-04 09:00:00', 'YYYY-MM-DD HH24:MI:SS'), TO_TIMESTAMP('2023-01-04 14:00:00', 'YYYY-MM-DD HH24:MI:SS'), NULL, NULL);